Compile SimpleOS
    javac simpleos/*/*.javac


Run SimpleOS
    java simpleos.sys.OS


NB: This is the commands that will be used to test your system, so do not change the structure of application.

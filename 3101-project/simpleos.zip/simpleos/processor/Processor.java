package simpleos.processor;

public abstract class Processor {

    public abstract int fetch();
    public abstract int execute();

} //end abstract class Processor
